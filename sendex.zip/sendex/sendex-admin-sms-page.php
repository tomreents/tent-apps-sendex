<?php
if (class_exists(\MailPoet\API\API::class)) {
  $mailpoet_api = \MailPoet\API\API::MP('v1');
}
?>

<head>
<!-- Allows multiple select without ctrl -->
<script type="text/javascript">
    function init() {
      if (arguments.callee.done) return;
      arguments.callee.done = true;
      if (khtmltimer) clearInterval(khtmltimer);
      var s = document.getElementsByTagName('select');
      for (var i = 0; i < s.length; i++) {
        if (s[i].hasAttribute('multiple')) {
          s[i].onclick = updateSelect;
        }
      }
    }
    function updateSelect(e) {
      var opts = this.getElementsByTagName('option'), t, o;
      if (e) {
        e.preventDefault();
        t = e.target;
      }
      else if (window.event) {
        window.event.returnValue = false;
        t = window.event.srcElement;
      }
      else return;
      t = e.target || window.event.srcElement;
      if (t.getAttribute('class') == 'selected') t.removeAttribute('class');
      else t.setAttribute('class', 'selected');
      for (var i = 0, j = opts.length; i < j; i++) {
        if (opts[i].hasAttribute('class')) opts[i].selected = true;
        else opts[i].selected = false;
      }
    }
         
    if (document.addEventListener) document.addEventListener("DOMContentLoaded", init, false);
    /*@cc_on @*/
    /*@if (@_win32)
        document.write("<script id=__ie_onload defer src=javascript:void(0)><\\/script>");
        var script = document.getElementById('__ie_onload');
        script.onreadystatechange = function() {
            if (this.readyState == 'complete') {
                init();
            }
        };
    /*@end @*/
    if (/KHTML/i.test(navigator.userAgent)) {
        var khtmltimer = setInterval(function() {
            if (/loaded|complete/.test(document.readyState)) {
                init();
            }
        }, 10);
    }
    window.onload = init;
  </script>
</head>

<h2> <?php esc_attr_e( 'Send message easily', 'WpAdminStyle' ); ?></h2>
<div class="wrap">
    <div class="metabox-holder columns-2">
        <div class="meta-box-sortables ui-sortable">
            <div class="postbox">
                <h2 class="hndle">
                    <span> <?php esc_attr_e( 'SEND SMS', 'WpAdminStyle' ); ?></span>
                </h2>
                <div class="inside">
                    <form method="post" name="cleanup_options" action="">
                        <input type="text" name="sender" class="regular-text" placeholder="Sender ID" required /><br><br>
                        <select name="list[]" id="list" multiple="multiple">
                            <option value="">Choose text group …</option>
                            <?php
                                // gets array of mailpoet lists 
                                $mailpoetList = $mailpoet_api->getLists();
                                
                                if( !is_null($mailpoetList) ) {
                                
                                    foreach( $mailpoetList as $list ) {
            
                                        echo '<option value="'. $list['id'] .'">'. $list['name'] .'</option>';
                                        
                                    }
                                }

                            ?>
                        </select>
                        <br><br>
                        <textarea name="message" cols="50" rows="7" placeholder="Message"></textarea><br><br>
                        <input class="button-primary" type="submit" value="SEND MESSAGE" name="send_sms_message" />
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<?php

/*
Plugin Name: Tent Apps Sendex
Plugin URI: https://github.com/tomreents/tent-apps-sendex
Description: A wordpress plugin for sending mass sms messages to Mailpoet Lists using Twillio
Version: 1.0.1
Author: Tent Apps
*/

define ( 'SENDEX_CURRENT_VERSION', '1.0.1' );

// Create custom post type replys
function create_reply() {
    register_post_type( 'sendex_reply',
        array(
            'label' => 'replys', 
            'public' => false, 
            'show_in_rest' => true,
            'show_ui' => true,
            'show_in_menu' => true
        )
    );
}

require_once( plugin_dir_path( __FILE__ ) .'/twilio-lib/src/Twilio/autoload.php');
use Twilio\Rest\Client;

class sendex {

    public $pluginName = "sendex";

    // renders sendex settings page
    public function displaySendexSettingsPage() {

       include_once "sendex-admin-settings-page.php";

   }
    // triggers opotions page
    public function addSendexAdminOption() {

        add_options_page(
            "SENDEX SMS PAGE",
            "SENDEX",
            "manage_options",
            $this->pluginName,
            [$this, "displaySendexSettingsPage"]
        );

    }

    /**
     * Registers and Defines the necessary fields we need.
     *  @since    1.0.0
     */
    public function sendexAdminSettingsSave() {

        register_setting(
            $this->pluginName,
            $this->pluginName,
            [$this, "pluginOptionsValidate"]
        );

        add_settings_section(
            "sendex_main",
            "Main Settings",
            [$this, "sendexSectionText"],
            "sendex-settings-page"
        );

        add_settings_field(
            "api_sid",
            "API SID",
            [$this, "sendexSettingSid"],
            "sendex-settings-page",
            "sendex_main"
        );

        add_settings_field(
            "api_auth_token",
            "API AUTH TOKEN",
            [$this, "sendexSettingToken"],
            "sendex-settings-page",
            "sendex_main"
        );

    }

    /**
     * Displays the settings sub header
     *  @since    1.0.0
     */
    public function sendexSectionText() {

        echo '<h3 style="text-decoration: underline;">Edit api details</h3>';

    }

    /**
     * Renders the sid input field
     *  @since    1.0.0
     */
    public function sendexSettingSid() {

        $options = get_option($this->pluginName);
        echo "
            <input
                id='$this->pluginName[api_sid]'
                name='$this->pluginName[api_sid]'
                size='40'
                type='text'
                value='{$options['api_sid']}'
                placeholder='Enter your API SID here'
            />
        ";

    }

    /**
     * Renders the auth_token input field
     *
     */
    public function sendexSettingToken() {

        $options = get_option($this->pluginName);
        echo "
            <input
                id='$this->pluginName[api_auth_token]'
                name='$this->pluginName[api_auth_token]'
                size='40'
                type='text'
                value='{$options['api_auth_token']}'
                placeholder='Enter your API AUTH TOKEN here'
            />
        ";

    }

    /**
     * Sanitizes all input fields.
     *
     */
    public function pluginOptionsValidate($input) {

        $newinput["api_sid"] = trim($input["api_sid"]);
        $newinput["api_auth_token"] = trim($input["api_auth_token"]);
        return $newinput;

    }

     /**
     * Register the sms page for the admin area.
     *  @since    1.0.0
     */
    public function registerSendexSmsPage() {

        // Create our settings page as a submenu page.
        add_submenu_page(
            "tools.php", // parent slug
            __("SENDEX SMS PAGE", $this->pluginName . "-sms"), // page title
            __("SENDEX SMS", $this->pluginName . "-sms"), // menu title
            "manage_options", // capability
            $this->pluginName . "-sms", // menu_slug
            [$this, "displaySendexSmsPage"] // callable function
        );

    }

    /**
     * Display the sms page - The page we are going to be sending message from.
     *  @since    1.0.0
     */
    public function displaySendexSmsPage() {

        include_once "sendex-admin-sms-page.php";

    }

    /**
     * returns an array of phone numbers from a mailpoet list
     *
     */ 
    public function get_numbers() {

        if (class_exists(\MailPoet\API\API::class)) {
            $mailpoet_api = \MailPoet\API\API::MP('v1');
          }

        global $wpdb;

        $table_name = $wpdb->prefix . "mailpoet_subscribers";
        $retrieve_data = $wpdb->get_results("SELECT * FROM $table_name");
        $subscribers_array = [];

        foreach ($retrieve_data as $retrieved_data) {

            $subscriber_array = array(
                'email' => $retrieved_data->email,
                 );

            array_push($subscribers_array, $subscriber_array);

        }

        $list_id   = (isset($_POST["list"])) ? $_POST["list"] : [];

        $numbers = array();

        foreach( $subscribers_array as $list ) {

            $subGetArry = $mailpoet_api->getSubscriber($list['email']);
            
            foreach( $subGetArry['subscriptions'] as $sub) {

                if( in_array($sub['segment_id'], $list_id) ) {
                    // cf_1 is the key for phone number 
                    $id = get_user_by( 'email', $list['email'] );
                    $id = $id->ID;
                    $phone = get_user_meta( $id, 'phone', true );
                    array_push($numbers, [$phone, $subGetArry['first_name'], $subGetArry['last_name']]);

                    break;
                }

            }

        }

        return $numbers;

    }

    public function send_message() {

        if ( !isset( $_POST["send_sms_message"] ) ) {
            return;
        }

        $sender_id = (isset($_POST["sender"]))  ? $_POST["sender"]  : "";
        $message   = (isset($_POST["message"])) ? $_POST["message"] : "";
        $numbers = $this->get_numbers();
        
        //gets our api details from the database.
        $api_details = get_option($this->pluginName);
        if (is_array($api_details) && count($api_details) != 0) {
            $TWILIO_SID = $api_details["api_sid"];
            $TWILIO_TOKEN = $api_details["api_auth_token"];
        }

        global $current_user;
        wp_get_current_user();

        $email = (string) $current_user->user_email;    

        try {
            $client = new Client($TWILIO_SID, $TWILIO_TOKEN);
            foreach( $numbers as $to) {
                $name = $to[1].' '.$to[2];
                $postarr = array(
                    'post_title' => $to[0],
                    'post_content' => $email.'|'.$name,
                    'post_type' => 'sendex_reply',
                    'post_status' => 'publish'
                );

                if( !post_exists( $to[0], '', '', 'sendex_reply') ) {

                    wp_insert_post( $postarr );
                   // $message = 'post does not exist';

                }
                else {

                    $post_id = post_exists( $to[0], '', '', 'sendex_reply');
                    $postarr = array(
                        'ID' => $post_id,
                        'post_title' => $to[0],
                        'post_content' => $email.'|'.$name,
                        'post_type' => 'sendex_reply'
                    );
                    wp_update_post( $postarr );
                    //$message = 'post does exist';
                }
                echo $to[0];
                echo $to[1];
                $response = $client->messages->create(
                    $to[0],
                    array(
                        "from" => $sender_id,
                        "body" => str_replace( '@name', $to[1],  $message ) 
                    )
                );
            }
            
            self::DisplaySuccess();
        } catch (Exception $e) {
            self::DisplayError($e->getMessage());
        }
        
    }

     /**
     * Designs for displaying Notices
     *
     * @since    1.0.0
     * @access   private
     * @var $message - String - The message we are displaying
     * @var $status   - Boolean - its either true or false
     */
    public static function adminNotice($message, $status = true) {

        $class =  ($status) ? "notice notice-success" : "notice notice-error";
        $message = __( $message, "sample-text-domain" );
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
         
    }

    /**
     * Displays Error Notices
     *
     * @since    1.0.0
     * @access   private
     */
    public static function DisplayError($message = "Aww!, there was an error.") {

        add_action( 'adminNotices', function() use($message) {
            self::adminNotice($message, false);
        });

    }

    /**
     * Displays Success Notices
     *
     * @since    1.0.0
     * @access   private
     */
    public static function DisplaySuccess($message = "Successful!") {

        add_action( 'adminNotices', function() use($message) {
            self::adminNotice($message, true);
        });

    }

}

/*************************************
 HOOKS
 *************************************/

 // Register custom post type
 add_action( 'init', 'create_reply' );

 // Create a new sendex instance
$sendexInstance = new Sendex();

// Add setting menu item
add_action("admin_menu", [$sendexInstance , "addSendexAdminOption"]);

// Saves and update settings
add_action("admin_init", [$sendexInstance , 'sendexAdminSettingsSave']);

// Hook our sms page
add_action("admin_menu", [$sendexInstance , "registerSendexSmsPage"]);

// calls the sending function whenever we try sending messages.
add_action( 'admin_init', [$sendexInstance , "send_message"] );

// Updates

add_filter('plugins_api', 'sendex_plugin_info', 20, 3);
/*
 * $res empty at this step
 * $action 'plugin_information'
 * $args stdClass Object ( [slug] => woocommerce [is_ssl] => [fields] => Array ( [banners] => 1 [reviews] => 1 [downloaded] => [active_installs] => 1 ) [per_page] => 24 [locale] => en_US )
 */
function sendex_plugin_info( $res, $action, $args ){

	// do nothing if this is not about getting plugin information
	if( 'plugin_information' !== $action ) {
		return false;
	}

	$plugin_slug = 'sendex'; // we are going to use it in many places in this function

	// do nothing if it is not our plugin
	if( $plugin_slug !== $args->slug ) {
		return false;
	}

	// trying to get from cache first
	if( false == $remote = get_transient( 'sendex_update_' . $plugin_slug ) ) {

		// info.json is the file with the actual plugin information on your server
		$remote = wp_remote_get( 'https://github.com/tomreents/tent-apps-sendex/blob/main/info.json', array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			) )
		);

		if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
			set_transient( 'sendex_update_' . $plugin_slug, $remote, 43200 ); // 12 hours cache
		}
	
	}

	if( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {

		$remote = json_decode( $remote['body'] );
		$res = new stdClass();

		$res->name = $remote->name;
		$res->slug = $plugin_slug;
		$res->version = $remote->version;
		$res->tested = $remote->tested;
		$res->requires = $remote->requires;
		$res->author = '<a href="https://tentapps.com/">Thomas Reents</a>';
		$res->author_profile = 'https://profiles.wordpress.org/tomreents';
		$res->download_link = $remote->download_url;
		$res->trunk = $remote->download_url;
		$res->requires_php = '5.3';
		$res->last_updated = $remote->last_updated;
		$res->sections = array(
			'description' => $remote->sections->description,
			'installation' => $remote->sections->installation,
			'changelog' => $remote->sections->changelog
			// you can add your custom sections (tabs) here
		);

		// in case you want the screenshots tab, use the following HTML format for its content:
		// <ol><li><a href="IMG_URL" target="_blank"><img src="IMG_URL" alt="CAPTION" /></a><p>CAPTION</p></li></ol>
		if( !empty( $remote->sections->screenshots ) ) {
			$res->sections['screenshots'] = $remote->sections->screenshots;
		}

		$res->banners = array(
			'low' => '',
			'high' => ''
		);
		return $res;

	}

	return false;

}

add_filter('site_transient_update_plugins', 'sendex_push_update' );
 
function sendex_push_update( $transient ){
 
	if ( empty($transient->checked ) ) {
            return $transient;
        }
 
	// trying to get from cache first, to disable cache comment 10,20,21,22,24
	if( false == $remote = get_transient( 'sendex_upgrade_sendex' ) ) {
 
		// info.json is the file with the actual plugin information on your server
		$remote = wp_remote_get( 'https://github.com/tomreents/tent-apps-sendex/blob/main/info.json', array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			) )
		);
 
		if ( !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
			set_transient( 'sendex_upgrade_sendex', $remote, 43200 ); // 12 hours cache
		}
 
	}
 
	if( $remote ) {
 
		$remote = json_decode( $remote['body'] );
 
		// your installed plugin version should be on the line below! You can obtain it dynamically of course 
		if( $remote && version_compare( SENDEX_CURRENT_VERSION, $remote->version, '<' ) && version_compare($remote->requires, get_bloginfo('version'), '<' ) ) {
			$res = new stdClass();
			$res->slug = 'sendex';
			$res->plugin = 'sendex/sendex.php'; // it could be just YOUR_PLUGIN_SLUG.php if your plugin doesn't have its own directory
			$res->new_version = $remote->version;
			$res->tested = $remote->tested;
			$res->package = $remote->download_url;
           		$transient->response[$res->plugin] = $res;
           		//$transient->checked[$res->plugin] = $remote->version;
           	}
 
	}
        return $transient;
}

add_action( 'upgrader_process_complete', 'sendex_after_update', 10, 2 );
 
function sendex_after_update( $upgrader_object, $options ) {
	if ( $options['action'] == 'update' && $options['type'] === 'plugin' )  {
		// just clean the cache when new plugin version is installed
		delete_transient( 'sendex_upgrade_sendex' );
	}
}
